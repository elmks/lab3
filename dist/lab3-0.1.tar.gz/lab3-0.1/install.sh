#!/bin/sh
pip install -r requirements.txt
sudo python3 setup.py install